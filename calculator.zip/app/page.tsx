"use client"

import Component from "../calculator"

export default function Page() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <Component />
    </main>
  )
}
